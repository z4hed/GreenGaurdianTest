package Models;

import java.time.LocalDateTime;

public class timeSeriesData {
    private LocalDateTime time;
    private float UV, moisture;
}
