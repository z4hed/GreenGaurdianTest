package Models;

import java.time.LocalDateTime;
import java.util.Queue;

public class plants {

    private String plantName;
    private LocalDateTime dateCreated;

    Queue<timeSeriesData> timedData;
}
